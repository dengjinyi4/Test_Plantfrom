Action()
{
/*���Ի���*/
    long fp1;
	fp1=fopen( "D:\\work\\auto\\lr\\1.txt",
		"a+" );
/*չʾ���*/
	web_set_max_html_param_len("102400");
	web_reg_save_param("code",
		"LB=\"code\":",
		"RB=,",
		LAST);
	web_reg_save_param("tag",
		"LB=\"tag\":\"",
		"RB=\"",
		"Ord=2",
		LAST);
	web_reg_save_param("adorder",
		"LB=\"adOrder\":{\"id\":",
		"RB=,\"",
		LAST);
	web_reg_save_param("biddingFactor",
		"LB=\"biddingFactor\":",
		"RB=,\"",
		LAST);
	web_reg_save_param("sp",
		"LB=\"sp\":",
		"RB=,\"",
		LAST);
	web_reg_save_param("ctr",
		"LB=\"ctr\":",
		"RB=,\"",
		LAST);
// lr_think_time(100);
	lr_save_datetime("%Y-%m-%d %H:%M:%S", DATE_NOW + TIME_NOW, "ad_biddingtTime");
	lr_start_transaction("ad_bidding");
/*����ʡ  ͨ���� 220.201.172.0 IOS android*/
	web_custom_request("web_custom_request",
		"URL=http://172.16.105.11:17091/ad_bidding.do?pids=1&uniq_tag={a}{a}&ip=172.16.148.119&cookie=dafads{a}{a}&device=android&adzone_id=102&pos_num=1_{no}&act_id=577",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Body=",
		LAST);
	if(atoi(lr_eval_string("{code}"))==0){
	lr_end_transaction("ad_bidding", LR_PASS);
	/*lr_message( "ad_bidding is ok" );
	lr_message( "this is tag=%s",lr_eval_string("{tag}") );
	lr_message( "this is adorder=%s",lr_eval_string("{adorder}") );*/

	}else{

	lr_end_transaction("ad_bidding", LR_FAIL);

	lr_error_message("code=%s", lr_eval_string("{code}"));

	}
	fprintf( fp1,
		"%s,%s,%s,%s,%s\n",
		lr_eval_string("{ad_biddingtTime}"),
		lr_eval_string("{adorder}"),
		lr_eval_string("{sp}"),
		lr_eval_string("{ctr}"),
		lr_eval_string("{biddingFactor}") );
	fclose( fp1 );
/*������*/

	lr_start_transaction("ad_click");
/*��� 219.150.32.0 chargeType=1 cpm chargeType=2 cpc�Ʒ�  */
	if ((atoi(lr_eval_string("{adorder}"))==928) || (atoi(lr_eval_string("{adorder}"))==608) || (atoi(lr_eval_string("{adorder}"))==609)) {
	web_custom_request("web_custom_request",
		"URL=http://172.16.105.11:17091/bridge.do?ip=222.163.255.255&agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+WOW64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F52.0.2729.4+Safari%2F537.36&refer=http%3A%2F%2Ft.ijifen.egou.com%3A8080%2Factivity%2F1.htm%3FlogId%3D24&mediaId=1&adZoneId=102&actId=577&adPlanId=3&adOrderId={adorder}&adCreativeId=10&userCookie=Mi8vMS8vMi8vMi8vMzY4MDUvLzE0OTUwOTEzMTAzMjQvL2U2MDZlYmYyNGRjODExYzY2ZGZlYzM3YjE1N2U0NTZhLy9jMjJhYzFhNjM4Yw==&url=https%3A%2F%2Fsale.jd.com%2Fact%2Fri17gqNDJaOMwZ.html%3Fcpdad%3D1DLSUE&chargeType=2&advertiserId=151&adChoosenTag={tag}&adzoneClickId=24&isCharge=1&logType=2&positionId=1&adLinkUrl=http://www.baidu.com",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Body=",
		LAST);
	lr_message( "111111111111111111111" );
	}
	else {
	web_custom_request("web_custom_request",
		"URL=http://172.16.105.11:17091/bridge.do?&ip=222.163.255.255&agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+WOW64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F52.0.2729.4+Safari%2F537.36&refer=http%3A%2F%2Ft.ijifen.egou.com%3A8080%2Factivity%2F1.htm%3FlogId%3D24&mediaId=1&adZoneId=102&actId=577&adPlanId=3&adOrderId={adorder}&adCreativeId=10&userCookie=Mi8vMS8vMi8vMi8vMzY4MDUvLzE0OTUwOTEzMTAzMjQvL2U2MDZlYmYyNGRjODExYzY2ZGZlYzM3YjE1N2U0NTZhLy9jMjJhYzFhNjM4Yw==&url=https%3A%2F%2Fsale.jd.com%2Fact%2Fri17gqNDJaOMwZ.html%3Fcpdad%3D1DLSUE&chargeType=2&advertiserId=151&adChoosenTag={tag}&adzoneClickId=24&isCharge=1&logType=2&positionId=1&adLinkUrl=http://www.baidu.com",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Body=",
		LAST);
	lr_message( "fddddddddddddddddd" );
	}

	lr_end_transaction("ad_click", LR_AUTO);



return 0;
}
